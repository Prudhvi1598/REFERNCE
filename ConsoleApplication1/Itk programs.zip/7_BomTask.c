#include<stdio.h>
#include<stdlib.h>
#include<tc\emh.h>
#include<tccore\item.h>
#include<tccore\aom_prop.h>
#include<tcinit\tcinit.h>
#include<tc/tc_startup.h>
int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	char *cError = NULL;

	tag_t

	iFail = ITK_init_module("hello", "hello", "dba");
	if (iFail == ITK_ok)
	{
		printf("Login Sucessfull\n");
		iFail= PS_create_bom_view()
	}

}
/*

PS_API int PS_create_bom_view	(	tag_t 	view_type,
const char * 	view_name,
const char * 	view_desc,
tag_t 	parent_item,
tag_t * 	bom_view
)	*/