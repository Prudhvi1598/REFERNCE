/* Write a ITK code to follow these steps: 

1.ITK_auto_login
2.find custom Item revision.
3.find list of secondary objects to IR.
4.In sec list if it's having PDF update object_name property value  to "ITK_Task"
5.ITK_exit_module.

*/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<tc\emh.h>
#include<tccore\item.h>
#include<tc/tc_startup.h>
#include<tcinit\tcinit.h>
#include<tccore\grm.h>
#include<tccore\aom_prop.h>
#include<tccore\aom.h>
#include<ae\dataset.h>

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i;
	int compare = 0;
	char *cError = NULL;
	char *values = NULL;
	char *propVal = NULL;
	char *type = "PDF";
	const char *object_name = NULL;
	tag_t tRev = NULLTAG;
	tag_t dataset = NULLTAG;
	int count = 0;
	//GRM_relation_t *tList=NULLTAG;
	tag_t *tList = NULL;
	tag_t tRelationType = NULLTAG;
	iFail = ITK_auto_login(true);
	if (iFail == ITK_ok)
	{
		printf("Login Sucessfully\n");
		iFail = ITEM_find_rev("000140", "A", &tRev);
		if (iFail == ITK_ok)
		{
			iFail = GRM_list_secondary_objects_only(tRev, NULLTAG, &count, &tList);
			if (iFail == ITK_ok)
			{
				for (i = 0; i < count; i++)
				{
					iFail = AOM_ask_value_string(tList[i], "object_type", &values);
					printf("secondary objects are: %s\n", values);
					compare = strcmp(values,type);
					if (compare == 0)
					{
						iFail = AOM_set_value_string(tList[i], "object_name", "ITK_TASK");
						AOM_save_without_extensions(tList[i]);
						if (iFail == ITK_ok) 
						{
							printf("Value set\n");
						}

						else
						{

							EMH_ask_error_text(iFail, &cError);
							printf("The error is :%s\n", cError);
						}
					}
					else
					{
						printf("It is not a pdf\n");
					}
					
				}
			}
			else
			{

				EMH_ask_error_text(iFail, &cError);
				printf("The error is :%s\n", cError);
			}

		}
		else
		{

			EMH_ask_error_text(iFail, &cError);
			printf("The error is :%s\n", cError);
		}
		
	}
	iFail = ITK_exit_module(true);
	if (iFail == ITK_ok)

	{
		printf("Logout Successful\n");

	}

	else {
		EMH_ask_error_text(iFail, &cError);
		printf("The error is :%s\n", cError);
	}
	
	return iFail;
}